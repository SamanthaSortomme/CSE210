using System;
using static System.Console;

class Program
{
    static void Main(string[] args)
    {
        Title = "Zegend of Lelda";
        CursorVisible = false;

        // try
        // {
        //     if (OperatingSystem.IsWindows())
        //     {
        //         WindowWidth = 130;
        //         WindowHeight = 35;
        //     }
        // }
        // catch
        // {
        //     WriteLine($" Cannot create a window console big enough.\nYou can continue playing but the game might not render properly");
        // }

        Game myGame = new Game();
        myGame.Start();
    }

    // static void

}